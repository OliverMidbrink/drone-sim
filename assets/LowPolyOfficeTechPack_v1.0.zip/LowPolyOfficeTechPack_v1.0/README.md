# Low Poly Office & Tech Pack (Free)
by reodesuxz

28 low poly office and tech props: desks, chairs, monitors, laptops, a server rack, printers and desk accessories.

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- OfficeTech_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 3288 triangles for all 28 models (32-444 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| office_desk | Furniture | 48 | 160 x 80 x 75 |
| office_chair | Furniture | 252 | 66 x 68 x 111 |
| filing_cabinet | Furniture | 120 | 45 x 65 x 130 |
| bookshelf | Furniture | 312 | 103 x 31 x 180 |
| whiteboard | Furniture | 120 | 140 x 50 x 184 |
| monitor | Computers | 48 | 60 x 18 x 51 |
| laptop | Computers | 60 | 34 x 27 x 23 |
| keyboard | Computers | 444 | 45 x 15 x 3 |
| computer_mouse | Computers | 32 | 6 x 10 x 4 |
| desktop_tower | Computers | 68 | 28 x 46 x 45 |
| server_rack | Computers | 300 | 60 x 83 x 190 |
| tablet | Computers | 36 | 25 x 15 x 19 |
| smartphone | Computers | 36 | 8 x 15 x 1 |
| headset | Computers | 164 | 23 x 15 x 10 |
| desk_speaker | Computers | 88 | 12 x 13 x 22 |
| wifi_router | Computers | 96 | 22 x 14 x 21 |
| printer | Office Equipment | 72 | 50 x 59 x 32 |
| photocopier | Office Equipment | 72 | 72 x 66 x 94 |
| projector | Office Equipment | 92 | 30 x 30 x 20 |
| desk_lamp | Desk Items | 100 | 20 x 38 x 51 |
| coffee_mug | Desk Items | 120 | 12 x 8 x 9 |
| pen_cup | Desk Items | 64 | 8 x 8 x 20 |
| paper_stack | Desk Items | 60 | 25 x 33 x 6 |
| stapler | Desk Items | 36 | 14 x 3 x 4 |
| office_plant | Desk Items | 116 | 29 x 29 x 63 |
| water_cooler | Office Equipment | 104 | 32 x 35 x 135 |
| wall_clock | Office Equipment | 160 | 40 x 7 x 40 |
| trash_bin | Office Equipment | 68 | 34 x 34 x 52 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
